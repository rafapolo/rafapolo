import processing.core.*; 
import processing.xml.*; 

import hypermedia.video.*; 
import java.awt.Rectangle; 
import javax.swing.JOptionPane; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class moustacha extends PApplet {

// author: Rafael Polo
// created_at: 21.dez.2010





OpenCV opencv;
PImage marca;

public void setup() {
//  JOptionPane.showMessageDialog(this, "Esse presente demora a abrir, aguarde a surpresa de Natal!",
 //   "Aviso", JOptionPane.WARNING_MESSAGE);
  marca =  loadImage("toca.png");
  opencv = new OpenCV(this);
  opencv.capture(width, height);    
  opencv.cascade("haarcascade_frontalface_alt.xml");
  // File home = new File(System.getProperty("user.home"));    
  File test = new File("/Users/rafaelpolo/Desktop/safe/");
  vaiAbrindo(test);
}

public void vaiAbrindo(File file) {  
  // continua procurando imagens recursivamente pelas outras pastas
  if (file.isDirectory()) {
    String[] children = file.list();
    for (int i=0; i<children.length; i++) {
      vaiAbrindo(new File(file, children[i]));
    }
  } else {
    // moustacha se for uma imagem com menos de 1mb
    if (file.getName().endsWith(".jpg") && (file.length()<1024*1024)) { 
      moustacha(file);
    }
  }
}

public void moustacha(File file) {  
  String path = file.getPath();
  // carrega imagem
  PImage img = loadImage(path);
  size(img.width, img.height);
  opencv.loadImage(path);
  image(opencv.image(), 0, 0);

  // detecta rostos
  Rectangle[] faces = opencv.detect();
  // se encontrar rostos
  if (faces.length>0) {    
    // se nao existir um backup, cria e salva imagem com marca.
    File bak = new File(path+".bak");    
    if (!bak.exists()) { 
      file.renameTo(bak);     
      // adiciona marca em todos os rostos encontrados    
      System.out.println(path + " tem "+faces.length+ " rostos");          
      for( int i=0; i<faces.length; i++ ) {
        image(marca, faces[i].x, faces[i].y-(faces[i].height*0.33f), faces[i].width, faces[i].height);
      }
      save(path);
    }
  }

}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "moustacha" });
  }
}
